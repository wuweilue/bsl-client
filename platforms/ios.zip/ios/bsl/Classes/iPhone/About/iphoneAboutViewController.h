//
//  iphoneAboutViewController.h
//  Cube-iOS
//
//  Created by Mr.幸 on 12-12-26.
//
//

#import <UIKit/UIKit.h>

@interface iphoneAboutViewController : UIViewController

@end
