//
//  Login_IphoneViewController.h
//  cube-ios
//
//  Created by 东 on 8/2/13.
//
//

#import <UIKit/UIKit.h>
@class CubeWebViewController;
@interface Login_IphoneViewController : UIViewController{
    CubeWebViewController *aCubeWebViewController ;
}

@end
