//
//  UIViewController+SEViewController.h
//  SESpringBoardDemo
//
//  Created by jac on 7/26/12.
//
//

#import <UIKit/UIKit.h>

@interface UIViewController (SEViewController)


-(void) setupCloseButtonWithImage:(UIImage *) closeImage;

@end
