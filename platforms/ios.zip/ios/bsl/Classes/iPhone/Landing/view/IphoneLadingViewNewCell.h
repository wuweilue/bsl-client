//
//  IphoneLadingViewNewCell.h
//  cube-ios
//
//  Created by 东 on 13-3-19.
//
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"

@interface IphoneLadingViewNewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet AsyncImageView *iconImageView;

@property (strong, nonatomic) IBOutlet UILabel *nameLable;

@end
