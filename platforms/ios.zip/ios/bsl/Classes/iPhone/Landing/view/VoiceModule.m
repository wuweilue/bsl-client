//
//  VoiceModule.m
//  TestVoiceView
//
//  Created by Mr.幸 on 12-12-8.
//  Copyright (c) 2012年 Mr.幸. All rights reserved.
//

#import "VoiceModule.h"

@implementation VoiceModule
@synthesize module;
@synthesize fileName;
@synthesize url;
@synthesize localUrl;
@synthesize dateAndtime;
@synthesize isUser;


@end
