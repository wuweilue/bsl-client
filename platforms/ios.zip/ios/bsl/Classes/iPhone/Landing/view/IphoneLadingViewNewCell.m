//
//  IphoneLadingViewNewCell.m
//  cube-ios
//
//  Created by 东 on 13-3-19.
//
//

#import "IphoneLadingViewNewCell.h"

@implementation IphoneLadingViewNewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
