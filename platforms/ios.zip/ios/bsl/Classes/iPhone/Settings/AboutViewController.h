//
//  AboutViewController.h
//  cube-ios
//
//  Created by 东 on 13-3-20.
//
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *versionLabel;
@property (strong, nonatomic) IBOutlet UILabel *driviceIdLabel;
@end
