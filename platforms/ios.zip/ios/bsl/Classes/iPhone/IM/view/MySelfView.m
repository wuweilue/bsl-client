//
//  MySelfView.m
//  cube-ios
//
//  Created by zhoujun on 13-6-24.
//
//

#import "MySelfView.h"

@implementation MySelfView
@synthesize fileName;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
