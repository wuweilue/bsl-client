//
//  MySelfView.h
//  cube-ios
//
//  Created by zhoujun on 13-6-24.
//
//

#import <UIKit/UIKit.h>

@interface MySelfView : UIButton
{
    NSString * fileName;
}
@property(strong,nonatomic) NSString * fileName;
@end
