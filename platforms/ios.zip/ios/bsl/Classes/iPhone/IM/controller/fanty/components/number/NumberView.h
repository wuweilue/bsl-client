//
//  NumberView.h
//  WeChat
//
//  Created by apple2310 on 13-9-4.
//  Copyright (c) 2013年 apple2310. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NumberView : UIImageView
-(void)number:(int)number;
@end
