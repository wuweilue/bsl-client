//
//  GroupManagerControllerViewController.m
//  cube-ios
//
//  Created by Mr Right on 13-8-13.
//
//

#import <Foundation/Foundation.h>


@interface NSMutableArray (NSMutableArray_Additions)

- (void)moveObjectFromIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex;

@end
