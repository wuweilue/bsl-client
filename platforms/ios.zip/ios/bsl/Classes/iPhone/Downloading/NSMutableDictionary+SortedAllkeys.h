//
//  NSMutableDictionary+SortedAllkeys.h
//  cube-ios
//
//  Created by chen shaomou on 4/26/13.
//
//

#import <Foundation/Foundation.h>

@interface NSMutableDictionary (SortedAllkeys)

-(NSArray *)sortedAllkeys;

-(NSArray *)sortedAllkeysBaseModuleEnd;
-(NSArray *)sortedAllkeysBaseModulePublicEnd;

@end
