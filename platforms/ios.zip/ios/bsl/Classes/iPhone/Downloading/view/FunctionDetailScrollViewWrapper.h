//
//  FunctionDetailScrollViewWrapper.h
//  Cube-iOS
//
//  Created by Pepper's mpro on 1/24/13.
//
//

#import <UIKit/UIKit.h>

@interface FunctionDetailScrollViewWrapper : UIView

@property (strong,nonatomic) UIScrollView *scrollView;

@end
