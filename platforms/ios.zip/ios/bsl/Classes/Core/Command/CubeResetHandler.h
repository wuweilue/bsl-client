//
//  CubeResetHandler.h
//  Cube-iOS
//
//  Created by Justin Yip on 2/2/13.
//
//

#import <Foundation/Foundation.h>
#import "CubeCommandHandler.h"

@interface CubeResetHandler : NSObject <CubeCommandHandler>

@end
