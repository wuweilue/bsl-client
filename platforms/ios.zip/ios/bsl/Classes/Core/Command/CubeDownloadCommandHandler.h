//
//  CubeDownloadCommand.h
//  Cube-iOS
//
//  Created by Justin Yip on 12/8/12.
//
//

#import <UIKit/UIKit.h>
#import "CubeCommandHandler.h"

@interface CubeDownloadCommandHandler : NSObject <CubeCommandHandler>

@end
