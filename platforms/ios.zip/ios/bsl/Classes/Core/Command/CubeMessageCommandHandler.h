//
//  CubeMessageCommandHandler.h
//  Cube-iOS
//
//  Created by Mr Right on 12-12-9.
//
//

#import <Foundation/Foundation.h>
#import "CubeCommandHandler.h"


@interface CubeMessageCommandHandler : NSObject<CubeCommandHandler>

@end
