//
//  AutoShowRecord.m
//  cube-ios
//
//  Created by zhoujun on 13-9-6.
//
//

#import "AutoShowRecord.h"

@implementation AutoShowRecord
@synthesize userName;
@synthesize identifier;
@synthesize showTime;
@end
