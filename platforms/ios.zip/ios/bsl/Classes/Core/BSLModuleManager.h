//
//  BSLModuleManager.h
//  bsl
//
//  Created by Justin Yip on 9/15/13.
//
//

#import <Foundation/Foundation.h>

//模块管理器，接入应用程序生命周期
@interface BSLModuleManager : NSObject

@end
