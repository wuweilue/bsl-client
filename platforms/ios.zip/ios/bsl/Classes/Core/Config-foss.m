NSString* const kServerURLString = @"http://115.28.1.119:18860";
NSString* const kServerLoginURLString = @"http://115.28.1.119:18860/system/api/system/mobile/accounts/login";
//NSString* const kServerURLString = @"http://10.108.68.136:9000";
NSString* const  kXMPPHost=@"115.28.0.60";
NSString* const  kAPIServerAPI=@"10.108.1.217:18860/csair-im/api";
NSString* const  kXMPPDomin=@"snda-192-168-2-32";
NSString* const  kPushServerRegisterUrl=@"http://115.28.1.119:18860/push/api/checkinservice/checkins";
NSString* const kUpdatePushTagsUrl = @"http:///115.28.1.119:18860/push/api/checkinservice/checkins/tags/";
NSString* const kAPPKey = @"f588301fae28ca0a97aa1efcbb7d3a9a";

NSString* const  kPushServerReceiptsUrl=@"http://115.28.1.119:18860/push/api/receipts";
NSString* const  kPushGetMessageUrl =@"http://115.28.1.119:18860/push/api/receipts/none-receipts";
NSString* const  kAPPName=@"com.foreveross.bslios";
int kXMPPPort= 5222;

NSString* const kFileUploadUrl = @"http://10.108.1.217:8080/bsl-web/mam/attachment/clientUpload";

NSString *const kMUCSevericeDomin=@"conference.snda-192-168-2-32";
