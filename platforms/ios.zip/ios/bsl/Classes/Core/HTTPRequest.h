//
//  HTTPRequest.h
//  PetNews
//
//  Created by fanty on 13-8-26.
//  Copyright (c) 2013年 fanty. All rights reserved.
//

#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.H"

@interface HTTPRequest : ASIHTTPRequest
-(void)cancel;
@end

@interface FormDataRequest : ASIFormDataRequest
-(void)cancel;

@end