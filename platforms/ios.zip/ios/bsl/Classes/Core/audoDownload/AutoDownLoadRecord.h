//
//  AutoDownLoadRecord.h
//  cube-ios
//
//  Created by zhoujun on 13-9-3.
//
//

#import <Foundation/Foundation.h>

@interface AutoDownLoadRecord : NSObject
@property (nonatomic, strong) NSString * identifier;
@property (nonatomic, strong) NSString * userName;
@property (nonatomic, strong) NSString * hasShow;

@end
