//
//  AutoDownLoadRecord.m
//  cube-ios
//
//  Created by zhoujun on 13-9-3.
//
//

#import "AutoDownLoadRecord.h"

@implementation AutoDownLoadRecord
@synthesize userName;
@synthesize identifier;
@synthesize hasShow;
@end
