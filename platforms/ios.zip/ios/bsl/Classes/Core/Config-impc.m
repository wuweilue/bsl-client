//
//  Config-impc.m
//  cube-ios
//
//  Created by zhoujun on 13-9-16.
//
//

NSString* const kServerURLString = @"http://192.168.11.18:18860";
NSString* const kServerLoginURLString = @"http://192.168.11.18:18860/csair-extension/api/accounts/login";
NSString* const  kXMPPHost=@"10.108.68.99";
NSString* const  kAPIServerAPI=@"192.168.11.18:18860/csair-im/api";
NSString* const  kXMPPDomin=@"mobile.app";
NSString* const  kPushServerRegisterUrl=@"http://192.168.11.18:18860/push/api/checkinservice/checkins";
NSString* const kUpdatePushTagsUrl = @"http:///192.168.11.18:18860/push/api/checkinservice/checkins/tags/";
NSString* const kAPPKey = @"c7342d0390ac6be8da4bdae0fcde5edf";

NSString* const  kPushServerReceiptsUrl=@"http://192.168.11.18:18860/push/api/receipts";
NSString* const  kPushGetMessageUrl =@"http://192.168.11.18:18860/push/api/receipts/none-receipts";
NSString* const  kAPPName=@"com.csair.impc";
int kXMPPPort= 5222;

NSString* const kFileUploadUrl = @"http://192.168.11.18:18860/bsl-web/mam/attachment/clientUpload";
NSString *const kMUCSevericeDomin=@"conference.mobile.app";

