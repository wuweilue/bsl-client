//
//  CollectedFriend.m
//  cube-ios
//
//  Created by zhoujun on 13-7-8.
//
//

#import "CollectedFriend.h"


@implementation CollectedFriend

@dynamic userId;
@dynamic friendId;

@end
