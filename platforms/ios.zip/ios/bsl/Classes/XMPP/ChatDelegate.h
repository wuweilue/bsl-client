//
//  ChatDelegate.h
//  XMPPIM
//
//  Created by 东 on 13-2-18.
//  Copyright (c) 2013年 imohoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSXMLElement+XMPP.h"
#import "UserInfo.h"

@protocol ChatDelegate <NSObject>
@optional
-(void)showFriends:(NSXMLElement*)array;
@end
