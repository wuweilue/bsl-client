//
//  RectangleChat.m
//  cube-ios
//
//  Created by 肖昶 on 13-9-15.
//
//

#import "RectangleChat.h"

@implementation RectangleChat

@dynamic chatId;
@dynamic chatMemberCount;
@dynamic content;
@dynamic contentType;
@dynamic createrJid;
@dynamic receiverJid;
@dynamic isGroup;
@dynamic updateDate;
@dynamic noReadMsgNumber;
@dynamic name;
@dynamic isQuit;
@end
