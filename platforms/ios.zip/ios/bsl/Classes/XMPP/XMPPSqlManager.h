//
//  XMPPSqlManager.h
//  cube-ios
//
//  Created by 东 on 13-4-17.
//
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface XMPPSqlManager : NSObject{
}

+(int)getMessageCount;
+(int)getMEssageCOuntFromGroup:(NSString*)groupName;


@end
