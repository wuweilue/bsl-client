//
//  GroupRoomUserEntity.m
//  cube-ios
//
//  Created by Mr Right on 13-8-20.
//
//

#import "GroupRoomUserEntity.h"

@implementation GroupRoomUserEntity
@dynamic roomName;
@dynamic roomId,jid,username,sex,statue,nickName;

@end
