//
//  BaseNavViewController.h
//  bsl
//
//  Created by 肖昶 on 13-10-9.
//
//

#import <UIKit/UIKit.h>

@interface BaseNavViewController : UINavigationController

@end
