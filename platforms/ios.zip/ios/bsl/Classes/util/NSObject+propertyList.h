//
//  NSObject+propertyList.h
//  Mcs
//
//  Created by chen shaomou on 8/23/12.
//  Copyright (c) 2012 RYTong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (propertyList)

- (NSArray *)getPropertyList;

- (NSDictionary *)formDictory;

@end
