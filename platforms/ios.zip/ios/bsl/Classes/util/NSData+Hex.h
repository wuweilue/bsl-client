//
//  NSData+Hex.h
//  Mcs
//
//  Created by shaomou chen on 5/23/12.
//  Copyright (c) 2012 RYTong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Hex)

- (NSString*) stringWithHexBytes;

@end
