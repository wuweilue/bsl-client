//
//  ConfigManager.h
//  Cube-iOS
//
//  Created by Mr Right on 12-12-8.
//
//

//
#define kServerPort 9000
//即时通讯数据库版本
#define kXMPPDataVersion 11

//#define kXMPPPort 5222        
#define kXMPPPushPort 5222


