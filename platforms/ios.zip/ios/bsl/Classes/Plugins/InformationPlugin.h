//
//  InformationPlugin.h
//  cube-ios
//
//  Created by hibad(Alfredo) on 13/3/18.
//
//

#import <Cordova/CDVPlugin.h>

@interface InformationPlugin : CDVPlugin


- (void)getInformation:(CDVInvokedUrlCommand*)command;

@end

