define(function(require) {
     var v1 = require('home/main');
     return {
         'main': v1
      };
});