define(function(require) {
     var v1 = require('com.csair.base/airports-list');
     var v2 = require('com.csair.base/cityBlock');
     var v3 = require('com.csair.base/competence');
     var v4 = require('com.csair.base/demoIndex');
     var v5 = require('com.csair.base/urlConfig');
     return {
         'airports-list': v1,
         'cityBlock': v2,
         'competence': v3,
         'demoIndex': v4,
         'urlConfig': v5
      };
});