define({
		"language":"zh-cn",
		"locale":"zh-cn",
		"mbp_ok":"确定",
		"mbp_tips":"提示",
		"mbp_unknow_error":"未知错误",
		'mbp_please_wait': '请稍候...',
		"mbp_al_back":"返回",
		"mbp_al_airportlist":"城市机场列表",
		"mbp_al_domestic":"国内城市",
		"mbp_al_international":"国际城市",
		"mbp_al_loadText":"加载中...",
		"mbp_al_searchText":"中文/拼音/英文",
		"checkin_queryTipsforCheckin":"抱歉!根据您提供的资料暂无法找到适合办理值机的航段,请至机场南航柜台办理"

}); 
 