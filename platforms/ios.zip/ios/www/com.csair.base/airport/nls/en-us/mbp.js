define({
	"root":{
		"language":"en-us",
		"locale":"en-us",
		"mbp_ok":"OK",
		"mbp_tips":"Tips",
		"mbp_unknow_error":"Unknow error",
		'mbp_please_wait': 'Please wait...',
		"mbp_al_back":"Back",
		"mbp_al_airportlist":"City Airpot List",
		"mbp_al_domestic":"Domestic City",
		"mbp_al_international":"International City",
		"mbp_al_loadText":"Loading...",
		"mbp_al_searchText":"Chinese/Pinyin/English",
		"checkin_queryTipsforCheckin":"Sorry! Based on your information, suitable segment for you to check in can't be found, please check in at airport counter."
	},
	"en-us":true,
	"zh-cn":true
}); 
 