define([], function() {
	var datas = {
		"groups": [{
				"gruopName": "所属公司",
				"cities": [{
					"cityName": "ALL 全部"
				}, {
					"cityName": "CAN 广州"
				}, {
					"cityName": "CGO 郑州"
				}, {
					"cityName": "CGQ 长春"
				}, {
					"cityName": "CKG 重庆"
				}, {
					"cityName": "DLC 大连"
				}, {
					"cityName": "HAK 海口"
				}, {
					"cityName": "HAK 海口"
				}, {
					"cityName": "HRB 哈尔滨"
				}, {
					"cityName": "KWE 贵阳"
				}, {
					"cityName": "KWL 桂林"
				}, {
					"cityName": "NNG 南宁"
				}, {
					"cityName": "PEK 北京"
				}, {
					"cityName": "PVG 浦东"
				}, {
					"cityName": "SHA 虹桥"
				}, {
					"cityName": "SHE 沈阳"
				}, {
					"cityName": "SWA 汕头"
				}, {
					"cityName": "SYX 三亚"
				}, {
					"cityName": "SZX 深圳"
				}, {
					"cityName": "URC 新疆"
				}, {
					"cityName": "WUH 武汉"
				}, {
					"cityName": "ZUH 珠海"
				}]
			}

		]
	}

	return datas;
});